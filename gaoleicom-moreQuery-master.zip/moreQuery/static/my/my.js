
var $,layedit,laypage,table,carousel,form,upload,element,laydate,treeGrid,Magnifier,tableSelect,dynamicCondition,treeSelect,xplAutocomplete;
var xplMSelect;
function initLayuiParam(layui){
	$ = layui.$;
	laypage = layui.laypage;
	layedit = layui.layedit;
	table = layui.table;
	form = layui.form;
	if(form){
		defineVerify();
	}
	upload = layui.upload;
	element = layui.element;
	laydate = layui.laydate;
	treeGrid = layui.treeGrid;
	tableSelect = layui.tableSelect;
	if(layui.Magnifier && layui.Event){
		Magnifier =new layui.Magnifier(new layui.Event(),{
            largeWrapper: document.getElementById('gallery-preview'),<!--预览图容器（必须）-->
        });
	}
	dynamicCondition = layui.dynamicCondition;
//	dynamicCondition.defaultValue.displayModel = "unpopup";
	treeSelect = layui.treeSelect;
	xplAutocomplete = layui.xplAutocomplete;
	carousel = layui.carousel;
	xplMSelect = layui.xplMSelect;
}

/***
 * 自定义表单验证
 */
function defineVerify(layui){
	form = form || layui.form;
	form.verify({
		  username: function(value, item){ //value：表单的值、item：表单的DOM对象
		    if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s·]+$").test(value)){
		      return '用户名不能有特殊字符';
		    }
		    if(/(^\_)|(\__)|(\_+$)/.test(value)){
		      return '用户名首尾不能出现下划线\'_\'';
		    }
		    if(/^\d+\d+\d$/.test(value)){
		      return '用户名不能全为数字';
		    }
		  }
		  //我们既支持上述函数式的方式，也支持下述数组的形式
		  //数组的两个值分别代表：[正则匹配、匹配不符时的提示文字]
		  ,pass: [
		    /^[\S]{6,12}$/
		    ,'密码必须6到12位，且不能出现空格'
		  ] 
		  ,phone: [/(^$)|^1(3|4|5|7|8)\d{9}$/, "请输入正确的手机号"]
          ,email: [/(^$)|^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/,'邮箱格式不正确']
          ,url: [           /(^$)|(^#)|(^http(s*):\/\/[^\s]+\.[^\s]+)/,'链接格式不正确']
          ,number: function(value){
            if(value != "" && (!value || isNaN(value))) return '只能填写数字'
          }
          ,date: [/(^$)|^(\d{4})[-\/](\d{1}|0\d{1}|1[0-2])([-\/](\d{1}|0\d{1}|[1-2][0-9]|3[0-1]))*$/,'日期格式不正确']
          ,identity: [/(^$)|(^\d{15}$)|(^\d{17}(x|X|\d)$)/,'请输入正确的身份证号' ]
		});      
}
/***
 * 获取url参数
 */
function getQueryString(name) { 
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
	var r = window.location.search.substr(1).match(reg); 
	if (r != null) 
		return decodeURI(r[2]);
	return null; 
} 
/***
 * form: 表单id,例子 getFormJson("#frm")
 * 返回：如：{Name:'摘取天上星',position:'IT技术'}
 * ps:注意将同名的放在一个数组里
 */
function getFormJson(form) {
	var o = {};
	var a = $(form).serializeArray();
		$.each(a, function () {
			if (o[this.name] !== undefined) {
				if (!o[this.name].push) {
					o[this.name] = [o[this.name]];
				}
				o[this.name].push(this.value || '');
			} else {
				o[this.name] = this.value || '';
			}
		});
	return o;
}

/**
 * 需要layui和baidu.template支持
 */
function addOrEdit(_op, _url, _data, _config){
	var _title = "编辑记录";
	if(_op == "add"){
		_title = "新增记录";
	}else if(_op == "edit"){
		_title = "编辑记录";
	}
	_data["_op"] = _op;
	var htmlContent = baidu.template('add_or_edit_form', _data);
	var default_config ={
			   type: 1
			   ,offset: "auto" //具体配置参考：http://www.layui.com/doc/modules/layer.html#offset
			   ,id: 'add_or_edit_form_layer' //防止重复弹出
			   ,title: _title
			   ,content: htmlContent
			   ,maxWidth:800
			   ,btn: ['提交','取消']
			   ,btnAlign: 'c' //按钮居中
			   ,shade: 0 //不显示遮罩
			   ,yes: function(){//提交
					form.on('submit(edit-lay-filter)', function(data){
		      	    	$.post(_url,data.field,function(data){
			      	        if(data.code == 0){
			      	        	layer.closeAll();
			      	        	var curPage = $(".layui-laypage-next").attr("data-page") - 1;
			      	        	table.reload("listTableId", {
			    	 	   			page: {
			    	 	   			  curr: curPage //重新加载当前页
			    	 	   			}
			    	 	   			,where: getFormJson("#frm")
			    	 	   		});
			      	        }
			      	        layer.msg(data.msg == "" ? _title +"成功！" : data.msg);
		      	    	});
		      	    	return false; //阻止表单跳转。如果需要表单跳转，去掉这段即可。
					});
			   		$("#editPageBtnId").click();
			 	}
			    ,btn2: function(){//取消
			    	   layer.close(idx);
			    }
			};
	if(typeof _config == "object" ){
		for (var key in _config){
			default_config[key] = _config[key];
			if(key == "yes"){
				default_config[key] = function(){
					_config[key](_url,_title );
				}
			}
	    }
    }
	var idx = layer.open(default_config);
	initLayuiParam(layui);
	disabledInput(_op);
	initDateInput($("#frmEdit .date"));
	resetSelectValue(_data.obj);
	return idx;
}

/**
 * 需要layui和baidu.template支持
 */
function deleteModel(formId, _url, _data){
	layer.confirm('真的要删除该记录么？', function(index){
		$.post(_url, _data,function(data){
			if(data.code == 0){
	        	//obj.del();
	        	var curPage = $(".layui-laypage-next").attr("data-page") - 1;
	        	table.reload("listTableId", {
	        		page: {
	        		  curr: curPage //重新加载当前页
	        		}
	        		,where: getFormJson(formId)
	        	});
	        	layer.close(index);
	        }
			layer.msg(data.msg == "" ? "删除成功！" : data.msg);
		});
	});
}
/***
 * 排序重载表格
 */
function tableReloadForSort($,formId,table,toPage,sortObj){
	//查询 执行重载table数据表格
	if(toPage == null){
		toPage = $(".layui-laypage-next").attr("data-page") - 1;
	}
	var whereObj = getFormJson(formId);
	if(typeof sortObj == "object" ){
		whereObj["sortField"] = sortObj.field; //排序字段
		whereObj["sortOrder"] = sortObj.type; //排序方式
    }
	table.reload("listTableId", {
		initSort: sortObj //记录初始排序，如果不设的话，将无法标记表头的排序状态。 layui 2.1.1 新增参数
		,page: {
		  curr: toPage //重新加载当前页
		}
		,where: whereObj
	});
	return false;
}

/**
 * 主键与自增字段在特定操作下，对应的元素设置为不可以编辑。
 */
function disabledInput(_op){
	var setDisabled = function(jqObjs){
		for(var i = 0; i<jqObjs.size();i++){
			jqObjs.eq(i).attr("readonly",true);
			jqObjs.eq(i).addClass("layui-disabled");
		}
	}
	//自增字段都是不可以编辑的。
	setDisabled($(".db-autoIncrement"));
	//如果是add操作，主键字段是可以编辑的
	//如果是edit操作，则主键字段是不可以编辑的。
	if(_op == "edit"){
		setDisabled($(".db-primaryKey"));
	}
	form.render();
}
/***
 * 对下拉框设置初始值。
 * select的name属性对应到data中查找对应的值，有则设置初始值。
 * jq_sels jquery对象数组。类似$("#frmEdit select")
 */
function resetSelectValue(data){
	var jq_sels = $("#frmEdit select");
	jq_sels.each(function(){
		var initValue = data[$(this).attr("name")];
		if(typeof initValue == "number" || typeof initValue == "string"){
			$(this).val(initValue);
		}
	})
	form.render('select');
}
/***
 * 初始化日期输入框
 * dateJqs jquery对象数组。类似$("#frmEdit .date")
 */
function initDateInput(dateJqs){
	dateJqs.each(function(){
		var dateType = $(this).attr("date-type");
		dateType = dateType || "date";
		laydate.render({
		    elem: this
		    ,type:dateType
		  });
		if(dateType == "date"){
			$(this).val(formatDateStr($(this).val()));
		}
	})
}

/***
 * 格式化日期字符串
 * dateStr 日期格式：yyyy-MM-dd hh:mm:ss
 * formatStr 转换后的格式：默认 yyyy-MM-dd
 */
function formatDateStr(dateStr, formatStr){
	if(!dateStr){
		return "";
	}
	formatStr = formatStr || 'yyyy-mm-dd';
	if(formatStr == 'yyyy-mm-dd'){
		return dateStr.substr(0,10)
	}
	return dateStr;
}

/***
 * layui table新增一行数据
 * 实现的思路是：当点击新增一行时，把之前的数据保存下来，并在数据尾部增加一行空数据,然后将新数据重新载入表格
 */
function addRow(tableId, rowObj,sort_callback){
	updateCacheOrForm(tableId,"cache");
	rowObj = rowObj || {};
	//定义一个空数组,用来存储之前编辑过的数据已经存放新数据
	var dataBak = [];   
	//获取之前编辑过的全部数据，前提是编辑数据是要更新缓存，stock_add_table 为表格的id
	var tableBak = table.cache[tableId]; 
	tableBak = tableBak || [];
	for (var i = 0; i < tableBak.length; i++) {
		//将之前的数组备份.如果是数组对象，表示该行记录已被删除
		if(!Array.isArray(tableBak[i])){
			dataBak.push( tableBak[i]);   
		}
	}
	//在尾部新增一行空数据，实现增行效果
	dataBak.push(rowObj);
	if(typeof sort_callback == "function"){
		dataBak.sort(sort_callback);
	}
	
	table.reload(tableId,{
	    data:dataBak   // 将新数据重新载入表格
	})
	updateCacheOrForm(tableId,"form");
	form.render();
	
}
/***
 * layui table 编辑一行数据
 */
function editRow(obj, rowObj, tableId, sort_callback){
	//同步更新缓存对应的值
    obj.update(rowObj);
    if(typeof sort_callback == "function"){
    	updateCacheOrForm(tableId,"cache");
    	var tableBak = table.cache[tableId]; 
    	tableBak.sort(sort_callback);
    	table.reload(tableId,{
    	    data:tableBak   // 将新数据重新载入表格
    	})
    	updateCacheOrForm(tableId,"form");
    	form.render();
	}
}

/***
 * layui table 删除一行数据
 */
function delRow(obj, tableId, sort_callback, callback){
	layer.confirm('真的要删除该记录么？', function(index){
		//同步更新缓存对应的值
		obj.del();
	    if(tableId){
	    	//重载表格数据前先缓存
	    	updateCacheOrForm(tableId,"cache");
	    	var dataBak = [];   
	    	//获取之前编辑过的全部数据，前提是编辑数据是要更新缓存，stock_add_table 为表格的id
	    	var tableBak = table.cache[tableId]; 
	    	tableBak = tableBak || [];
	    	for (var i = 0; i < tableBak.length; i++) {
	    		//将之前的数组备份.如果是数组对象，表示该行记录已被删除
	    		if(!Array.isArray(tableBak[i])){
	    			dataBak.push( tableBak[i]);   
	    		}
	    	}
	    	if(typeof sort_callback == "function"){
	    		dataBak.sort(sort_callback);
	    	}
	    	table.reload(tableId,{
	    	    data:dataBak   // 将新数据重新载入表格
	    	})
	    	updateCacheOrForm(tableId,"form");
	    	form.render();
		}
	    layer.close(index);
	    if(typeof callback == "function"){
	    	callback();
    	}
	});
}

/***
 * 格式化请求参数,数组转换为一个对象
 * list 数据列表，例如 [{id:1,name:"test1",email:"11111@qq.com"},{id:2,name:"test2",email:"222222@qq.com"}}
 * beanName 数据实体名称,例如： user
 * 返回结果：{userArrSize:2,user0.id:1,user0.name:"test1",user0.email:"11111@qq.com",user1.id:2,user1.name:"test2",user1.email:"222222@qq.com"}
 */
function formatParams(list, beanName){
	list = list || [];
	var rs = {};
	var beanNameArrSize = 0;
	for(var i = 0;i<list.length;i++ ){
		var tempObj = list[i];
		if(tempObj.length == 0){
			continue;
		}
		for (var key in tempObj){
			rs[beanName + beanNameArrSize + "." + key] = tempObj[key];
	    }
		beanNameArrSize++;
	}
	rs[beanName + "ArrSize"] = beanNameArrSize;
	return rs;
}

/***
 * updateCacheOrForm(tableId, tableCacheId, op) tableId和tableCacheId最后保持一致。
 * op="cache",则更新表格数据，将表格编辑控件数据更新到缓存table.cache[tableCacheId]; 
 * op="form"，则从缓存table.cache[tableCacheId]获取数据更新表格对应的下拉框，日期等控件。
 * op: 取值cache或者form。默认form
 */
function updateCacheOrForm(tableId, op){
	op = op || "form";
	var divForm = $("#" + tableId).next();
	var tableCache = table.cache[tableId]; 
	var trJqs = divForm.find(".layui-table-body tr");
	trJqs.each(function(){
		var trJq = $(this);
		var dataIndex = trJq.attr("data-index");
		trJq.find("td").each(function(){
			var tdJq = $(this);
			var fieldName = tdJq.attr("data-field");
			//var fieldName = selectJq.eq(0).attr("name");
			//更新select数据
			var selectJq = tdJq.find("select");
			if(selectJq.length == 1){
				if(op == "cache"){
					tableCache[dataIndex][fieldName] = selectJq.eq(0).val();
				}else if(op == "form"){
					selectJq.eq(0).val(tableCache[dataIndex][fieldName])
				}
			}
			//更新日期输入框数据
			var inputJq = tdJq.find(".layui-input.date");
			if(inputJq.length == 1){
				if(op == "cache"){
					tableCache[dataIndex][fieldName] = inputJq.eq(0).val();
				}else if(op == "form"){
					inputJq.eq(0).val(tableCache[dataIndex][fieldName]);
					initDateInput(inputJq);
				}
			}
			//更新inputTags
//			var inputJq = tdJq.find(".layui-input.date");
//			if(inputJq.length == 1){
//				if(op == "cache"){
//					tableCache[dataIndex][fieldName] = inputJq.eq(0).val();
//				}else if(op == "form"){
//					inputJq.eq(0).val(tableCache[dataIndex][fieldName]);
//					initDateInput(inputJq);
//				}
//			}
		});
	});
	if(op == "form"){
		//添加样式
		$(".layui-table-cell select").each(function(){
			var tdJq = $(this).parent();
			while(!tdJq.hasClass("layui-table-cell")){
				tdJq = $(tdJq).parent();
			}
			tdJq.css("overflow", "visible");
		});
		form.render('select');
	}
	
	return tableCache;
}

/***
 * 获取指定下拉框value对应的label值
 */
function getDictLabel(selectId,value){
	if($("#"+selectId).length == 0){
		console.log("未找到id为“"+selectId+"”元素。")
		return "";
	}
	var options = $("#"+selectId).find("option");
	var rs = "";
	options.each(function(){
		if($(this).val() == value){
			rs = $(this).text();
		}
	});
	return rs;
}

/***
 * 图片弹出展示,默认原大小展示。图片大于浏览器时下窗口可视区域时，进行等比例缩小。
 * config.src 图片路径。必须项
 * default_config.height 图片显示高度，默认原大小展示。图片大于浏览器时下窗口可视区域时，进行等比例缩小。
 * default_config.width 图片显示宽度，默认原大小展示。图片大于浏览器时下窗口可视区域时，进行等比例缩小。
 * default_config.title 弹出框标题
 */
function previewImg(config) {
	if(!config.src || config.src==""){
		layer.msg("没有发现图片！");
		return ;
	}
	var min_width = 160;
	var default_config = {title: "图片预览"};
	var img = new Image();  
    img.onload = function() {//避免图片还未加载完成无法获取到图片的大小。
    	//避免图片太大，导致弹出展示超出了网页显示访问，所以图片大于浏览器时下窗口可视区域时，进行等比例缩小。
    	var max_height = $(window).height() - 100;
    	var max_width = $(window).width();
    	//rate1，rate2，rate3 三个比例中取最小的。
    	var rate1 = max_height/img.height;
    	var rate2 = max_width/img.width;
    	var rate3 = 1;
    	var rate = Math.min(rate1,rate2,rate3); 
    	//等比例缩放
    	default_config.height = img.height * rate; //获取图片高度
        default_config.width = img.width  * rate; //获取图片宽度
        //宽度小于最小值，那么放大到最小宽度
        if(default_config.width < min_width){
        	rate = min_width / default_config.width;
        	default_config.height = default_config.height * rate; //获取图片高度
            default_config.width = default_config.width  * rate; //获取图片宽度
        }
        
        $.extend( default_config, config);
        var imgHtml = "<img src='" + default_config.src + "' width='"+default_config.width+"px' height='"+default_config.height+"px'/>";  
        //弹出层
        layer.open({  
            type: 1,  
            shade: 0.8,
            offset: 'auto',
            area: [default_config.width + 'px',default_config.height + 50 +'px'], ////宽，高
            shadeClose:true,
            scrollbar: false,
            title: default_config.title, //不显示标题  
            content: imgHtml, //捕获的元素，注意：最好该指定的元素要存放在body最外层，否则可能被其它的相对元素所影响  
            cancel: function () {  
                //layer.msg('捕获就是从页面已经存在的元素上，包裹layer的结构', { time: 5000, icon: 6 });  
            }  
        }); 
    }
    img.src = config.src;
}
/***
 * 表格td中显示图片
 */
function tableTdShowImg(src){
	return '<img style="height:28px;" onclick="previewImg({src:this.src})" src="'+src+'" ></img>';
}
/***
 * 表格td中显示图片列表
 * imgPathList.可以为null，或者"",或者包含多个图片，多个图片路径默认用逗号分隔
 */
function showImgList(imgPathList,separatorStr){
	separatorStr = separatorStr || ",";
	imgPathList = imgPathList || "";
	var imgPathArr =  imgPathList == "" ? [] : imgPathList.split(separatorStr);
	var htmlStr = "";
	for(var i=0;i<imgPathArr.length;i++){
		htmlStr += tableTdShowImg(imgPathArr[i]);
	}
	return htmlStr;
}
/***
 * 表格td中格式化显示日期类型
 * formatStr=all 对应格式 yyyy-MM-dd hh:mm:ss
 * formatStr=date 对应格式 yyyy-MM-dd
 */
function tdFormatDate(dateStr, formatStr){
	dateStr = dateStr || "";
	formatStr = formatStr || 'date';
	if(formatStr == "date"){
		//substring(start,end)
		return dateStr.substring(0,10);
	}
	return dateStr;
}


/***
 * 必须的参数：url,id,idField,treeUpId,cols
 * 常用的参数：height,treeShowName
 */
function treeGridRender(params){
	var tableId = params.id;
	var default_params = {
	        id: tableId
	        ,elem: '#'+ tableId
	        ,idField:'apiURL'
	        //,url:'/appName/admin/api/listAll'
	        ,cellMinWidth: 100
	        //,treeId:'apiURL'//树形id字段名称
	        ,treeId:params.idField//树形id字段名称
	        ,treeUpId:params.treeUpId//树形父id字段名称
	        //,treeShowName:'apiURL'//以树形式显示的字段
	        ,treeShowName: params.idField//以树形式显示的字段
	        ,heightRemove:[".dHead",10]//不计算的高度,表格设定的是固定高度，此项不生效
	        //,height: tableDivHeight
	        ,height: 300
	        ,isFilter:false
	        ,toolbar: '#toolbarBts'
	        ,iconOpen:true//是否显示图标【默认显示】
	        ,isOpenDefault:false//节点默认是展开还是折叠【默认展开】
	        ,cols: [[
	            {type:'numbers'}
	            ,{field:params.idField, title: params.idField,sort:false} 
	     	   ,{field:params.treeShowName, title: params.treeShowName,sort:false} 
	     	  //,{field:'parApiURL', title: '父节点',sort:false} 
	           ,{fixed: 'right', width:178, align:'center', toolbar: '#barBtns',title: '操作'} 
	        ]]
	        ,page:false
	        ,parseData:function (res) {//数据加载后回调
	            return res;
	        }
			,onClickRow:function (index, o) {
//	          console.log(index,o,"单击");
//				openorclose(o.apiURL);
			}
	        ,onDblClickRow:function (index, o) {
//	            console.log(index,o,"双击");
	            _openorclose(tableId,  o[params.idField]);
	        }
	    };
	$.extend( default_params, params);
	//隐藏或打开指定节点
	var _openorclose = function (tableId, id) {
	    var map=treeGrid.getDataMap(tableId);
	    var o= map[id];
	    treeGrid.treeNodeOpen(tableId,o,!o[treeGrid.config.cols.isOpen]);
	};
	var ptable=treeGrid.render(default_params);
	return ptable;
}

/***
 * 批量导入
 * config.downUrl 下载模板url
 * config.uploadUrl 上传文件url
 * config.msg
 * config.done 上传结束后执行。
 */
function importData(config){
	var default_config = {
			msg:"数据导入成功！"
			,title:'导入记录'
	}
	$.extend( default_config, config);
	var idRandom = "importData" + Math.ceil(Math.random()*10000)
	var htmlContent = '<div class="layui-upload-drag" id="'+idRandom+'">';
	htmlContent += '<i class="layui-icon"></i>';
	htmlContent += '<p>点击上传，或将文件拖拽到此处</p>';
	htmlContent += '</div>';
	
	layer.open({
	      type: 1
	      ,offset: "auto" //具体配置参考：http://www.layui.com/doc/modules/layer.html#offset
	      ,id: 'layer_importData' //防止重复弹出
	      ,title:default_config.title
	      ,content: htmlContent
	      ,maxWidth:800
	      ,btn: ['下载模板']
	      ,btnAlign: 'c' //按钮居中
	      ,shade: 0 //不显示遮罩
	      ,yes: function(){//提交
	    	  	var iframe = $("<iframe></iframe>");
	    	  	iframe.attr("src",default_config.downUrl);
	    	  	iframe.css("display","none");
	    	  	$("#"+idRandom).append(iframe);
	      }
	});
	form.render();
	//拖拽上传
	upload.render({
	      elem: "#"+idRandom
	      ,url: default_config.uploadUrl
	      ,accept: 'file'
	      ,done: function(data){
	    	  if(data.code == 0){
	   	        	layer.closeAll();
	   	        	if($("#query")){
	   	        		$("#query").click();
	   	        	}
	   	        	if(default_config.done){
	   	        		default_config.done(data);
	   	        	}else{
	   	        		layer.msg(default_config.msg);
	   	        	}
 	        	}else{
 	        		layer.msg(data.msg);
 	        	}
	      }
	});
}

/***
 * 提示信息
 * templateId 模板id
 * data 数据
 */
function layuiShowMsg(config){
	var default_config = {
			title:"提示"
			,width: 450
			,height: 350
	}
	$.extend( default_config, config);
	var htmlContent = baidu.template(default_config.templateId, default_config.data);
	var max_height = $(window).height() - 100;
	var max_width = $(window).width() - 50;
	//layer.alert(htmlContent, {icon: 6});
	layer.open({
	      type: 1
	      ,shade: 0.8
	      ,shadeClose:true
	      ,offset: "auto" //具体配置参考：http://www.layui.com/doc/modules/layer.html#offset
	      ,id: 'layer_showMsg' //防止重复弹出
	      ,title:default_config.title
	      ,content: htmlContent
	      ,maxHeight: max_height
	      ,maxWidth: max_width
	      ,area: [default_config.width + 'px',default_config.height + 50 +'px'] ////宽，高
	      ,btnAlign: 'c' //按钮居中
	});
}
/***
 * 逻辑删除
 */
function logicDel(obj,url,tableId) {
	$.post(url, obj.data,function(data){
		if(data.code == 0){
			if(obj.data.logicDel == "Y"){
				obj.data.logicDel = "N";
			}else{
				obj.data.logicDel = "Y";
			}
			//刷新表格
	        //table.reload(tableId, {});
			layer.msg(data.msg == "" ? "操作成功！" : data.msg);
        }else{
        	layer.msg(data.msg);
        }
	});
}

/***
 * 逻辑删除
 */
function logicDelSwitch(url,tableId,obj) {
	// 获取当前控件                                                                
	var selectIfKey=obj.othis;                                               
	// 获取当前所在行                                                               
	var parentTr = selectIfKey.parents("tr");                                
	// 获取当前所在行的索引                                                            
	var parentTrIndex = parentTr.attr("data-index");                 
	var tableData = table.cache[tableId]; 
	if(!tableData){
		tableData = treeGrid.cache[tableId].data.list;
	}
	var rowData = tableData[parentTrIndex];
	$.post(url, rowData,function(data){
		if(data.code == 0){
			if(rowData.logicDel == "Y"){
				rowData.logicDel = "N";
			}else{
				rowData.logicDel = "Y";
			}
			//刷新表格
	        table.reload(tableId, {});
			layer.msg(data.msg == "" ? "操作成功！" : data.msg);
        }else{
        	layer.msg(data.msg);
        }
	});
}
/***
 * 渲染富文本编辑器
 * eleId:例子：'details'
 * config：https://www.layui.com/doc/modules/layedit.html
 */
function richTextEditor(eleId,config){
	config = config || {'uploadImage':{url:'/'+appName+'/admin/imgResource/uploadImg'}};
	return layedit.build(eleId,config); //建立编辑器
}

/***
 * JS 取得一个区间的随机整数
 * 默认（不带参数）随机一个自然数。
 */
function rnd(n, m){
	n = n || 1;
	m = m || 99999999999999;
    var random = Math.floor(Math.random()*(m-n+1)+n);
    return random;
}

/***
 * 获取一个递增id。初始从1开始
 */
function getAddId(str){
	window[str] = window[str] || 1;
    return window[str]++;
}


